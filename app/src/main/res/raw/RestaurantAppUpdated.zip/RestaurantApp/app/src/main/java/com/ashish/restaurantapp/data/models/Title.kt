package com.ashish.restaurantapp

data class Title(
    val text: String
)