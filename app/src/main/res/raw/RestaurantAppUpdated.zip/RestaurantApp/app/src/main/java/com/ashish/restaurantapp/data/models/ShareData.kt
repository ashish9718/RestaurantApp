package com.ashish.restaurantapp

data class ShareData(
    val should_show: Int
)