package com.ashish.restaurantapp.cloudmessaging

data class NotificationData(
    val title: String,
    val message: String
)