package com.ashish.restaurantapp

data class Photo(
    val photo: PhotoX
)