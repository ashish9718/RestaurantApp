package com.ashish.restaurantapp

data class BgColor(
    val tint: String,
    val type: String
)