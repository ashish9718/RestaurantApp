package com.ashish.restaurantapp

data class ZomatoEvent(
    val event: Event
)