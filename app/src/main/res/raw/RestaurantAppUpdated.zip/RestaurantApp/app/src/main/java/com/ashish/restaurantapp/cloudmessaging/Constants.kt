package com.ashish.restaurantapp.cloudmessaging

class Constants {
    companion object {
        const val BASE_URL = "https://fcm.googleapis.com"
        const val SERVER_KEY = "AAAAJddO3zM:APA91bHmOt-2M2G5xW7GkikDT4er7QksGvrViA3z8oo0MUw9BhRvPGD9fMh11f3Zve-Jyiwt6HNUTMkaKfJVuWl4LtMp97FmxeNEOY2p2zwg31Aa2dr0HfF7usAjv9nPSOREO204rhXv"
        const val CONTENT_TYPE = "application/json"
    }
}