package com.ashish.restaurantapp.data.models

data class UserModel(
    var name: String = "",
    var email :String = "",
    var pic: String ="",
    var pic_bg: String = ""
)
