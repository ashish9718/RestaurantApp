package com.ashish.restaurantapp.data.models

class EatWhat(
    var name: String,
    var imageUrl: Int
)

