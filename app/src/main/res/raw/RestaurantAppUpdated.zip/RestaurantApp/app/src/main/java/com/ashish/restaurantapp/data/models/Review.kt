package com.ashish.restaurantapp

data class Review(
    val review: List<Any>
)