package com.ashish.restaurantapp.data.models


data class Restaurant(
    var restaurant: RestaurantX
)