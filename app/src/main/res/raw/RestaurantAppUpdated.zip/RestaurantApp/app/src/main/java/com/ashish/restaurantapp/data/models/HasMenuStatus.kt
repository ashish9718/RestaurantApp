package com.ashish.restaurantapp

data class HasMenuStatus(
    val delivery: Any,
    val takeaway: Int
)