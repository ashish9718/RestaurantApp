package com.ashish.restaurantapp.data.models

import com.ashish.restaurantapp.Review


data class AllReviews(
    val reviews: List<Review>
)