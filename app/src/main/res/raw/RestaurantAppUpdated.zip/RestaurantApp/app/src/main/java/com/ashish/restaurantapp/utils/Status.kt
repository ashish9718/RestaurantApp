package com.ashish.restaurantapp.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}