package com.ashish.restaurantapp

data class RatingObj(
    val bg_color: BgColor,
    val title: Title
)